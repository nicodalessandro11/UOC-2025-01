# *Are-u-Queryous?*

NOTE: This functionality is optional and has not been yet implemented

## License & Ownership

This **NLP Implementation** was designed and documented by Nico Dalessandro  
for the UOC Final Degree Project (TFG) — "Are-u-Queryous?"

All code and scripts in this repository are released under the [MIT License](./LICENSE).  
You are free to use, modify, and distribute them with proper attribution.
