package parsingTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import japa.parser.JavaParser;
import japa.parser.ParseException;

public class ParsingTest {

	public static void main(String[] args) {
		String filename = args[0];
		InputStream bais = null;
		try {
			bais = new FileInputStream(new File(filename));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{
			JavaParser.parse(bais);
		} catch  (ParseException e){
			System.err.println("Parse error at " + filename + " " + e.getMessage()+"\n");
//			e.printStackTrace();
			System.exit(-1);
		} 

		System.out.println("Parsing ok");
	}
}
