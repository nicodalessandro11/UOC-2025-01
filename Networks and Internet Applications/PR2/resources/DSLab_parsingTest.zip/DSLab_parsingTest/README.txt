java -classpath ./bin:./lib/* parser.ParsingTest <file_to_parse>

Two demo files are provided:
* fitxerCorrecte.java: no parse errors.
* fitxerErroni.java: contains parse errors.