#!/bin/bash
TOKEN=$1



